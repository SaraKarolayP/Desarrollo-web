let numeros = [11, 21, 53, 43, 85];

//Agregar un número al final del arreglo
const agregarNumero = (num) => {
  numeros.push(num);
  return numeros;
};

console.log("1. Números Iniciales:", numeros);
console.log("2. Agregar Número:", agregarNumero(6));

let frutas = ["Manzana", "Banana", "Naranja","Mandarina"];

//Eliminar la última fruta del arreglo
const eliminarUltimaFruta = () => {
  frutas.pop();
  return frutas;
};

console.log("3. Frutas:", frutas);
console.log("4. Eliminar Última Fruta:", eliminarUltimaFruta());

let palabras = ["Hola", "Mundo", "Web"];

// Unir dos arreglos
const unirArreglos = (otroArreglo) => palabras.concat(otroArreglo);

console.log("5. Palabras:", palabras);
console.log("6. Unir Arreglos:", unirArreglos(["Nuevas", "Tecnologias"]));

let numerosADuplicar = [2, 4, 6, 8, 10];

// Duplicar cada elemento del arreglo
const duplicarNumeros = () => numerosADuplicar.map((numero) => numero * 2);

console.log("7. Números a Duplicar:", numerosADuplicar);
console.log("8. Duplicar Números:", duplicarNumeros());

let precios = [50, 30, 20, 40, 10];

// Filtrar precios menores a 30
const filtrarPrecios = () => precios.filter((precio) => precio < 30);

console.log("9. Precios:", precios);
console.log("10. Filtrar Precios Menores a 30:", filtrarPrecios());
