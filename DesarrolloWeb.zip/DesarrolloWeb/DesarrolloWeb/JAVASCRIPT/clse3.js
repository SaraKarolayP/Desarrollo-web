// Arrow function que recibe cero parámetros
const zeroParams = () => {
    const message = "Esta función no recibe parámetros.";
    console.log(message);
};

// Arrow function que recibe un parámetro
const oneParam = (param) => {
    let squared = Math.pow(param, 2);
    console.log(`El cuadrado de ${param} es ${squared}.`);
};

// Arrow function que recibe más de dos parámetros
const multipleParams = (...params) => {
    let sum = params.reduce((acc, curr) => acc + curr, 0);
    let avg = sum / params.length;
    let max = Math.max(...params);
    let min = Math.min(...params);
    let message = `Suma: ${sum}, Promedio: ${avg}, Máximo: ${max}, Mínimo: ${min}`;
    console.log(message);
};

// Arrow function extra
const contarLetrasYBuscar = (nombreUsuario, letra) => {
    const cantidadLetras = nombreUsuario.length;
    console.log(`El nombre de usuario tiene ${cantidadLetras} letras.`);
  
    const incluyeLetra = nombreUsuario.includes(letra);
    console.log(`¿El nombre de usuario incluye la letra "${letra}"?: ${incluyeLetra}`);
};

let nombreUsuario = "NATALIA";
contarLetrasYBuscar(nombreUsuario, "T");

zeroParams();
oneParam(5);
multipleParams(2, 4, 6, 8, 10);
